<?php
$host = "localhost"; //host server
$user = "skuypayc_bulebali"; //user login phpMyAdmin
$pass = "jolulus2023"; //pass login phpMyAdmin
$db = "skuypayc_bulebali"; //nama database
$koneksi = mysqli_connect($host, $user, $pass, $db) or die("Koneksi gagal");
